



import java.awt.Desktop;





import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import org.apache.log4j.Logger;


//import javax.swing.JPanel;
//import javax.swing.border.EmptyBorder;


public class Login extends JFrame {
	
	
	Logger logger=Logger.getLogger(Login.class);
	
	private JTextField userField;
	private JPasswordField passwordField;
	 Person p1=new Person();
	

	boolean sucess=false;
	
	

	
	JLabel userLabel = new JLabel("User Name   :");
	JLabel passLabel = new JLabel("PassWord    :");

	JButton regBtn = new JButton("Register");
	JLabel regSucess;

	JButton logBtn = new JButton("Login");
	
	public static void main(String[] args) {
	
					Login frame = new Login();
					frame.setVisible(true);
					frame.setTitle("login screen");
				
					/*Login lg=new Login();*/
				
	}
	public void  register(){
		
		
			p1.setUsername(userField.getText().trim());
		
		
		p1.setPassword(passwordField.getText().trim());
		
		
		
		if(p1.getUsername().length() > 0 && p1.getPassword().length()>0){
			//System.out.println("in condition 1");
			logger.debug("reg sucess");
			sucess=true;
		
		}
		else{
			//System.out.println("in condition 2");
			logger.debug("reg failed");
			sucess=false;
		}
		
		}
		
	

	
	public Login() {
		
		
		//try {
			
		//	Serial.idCounter();
		//	logger.debug("edu is "+Serial.eduLoan);
		//	logger.debug("car is "+Serial.carLoan);
		//	logger.debug("home is "+Serial.homeLoan);
		//} catch (FileNotFoundException e2) {
			
		//	logger.debug("no files before");
		//}
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 829, 491);
		getContentPane().setLayout(null);
		
		userField = new JTextField();
		userField.setToolTipText("Enter User Name");
		userField.setBounds(263, 62, 105, 20);
		getContentPane().add(userField);
		userField.setColumns(10);
		
		
		userLabel.setBounds(149, 65, 80, 14);
		getContentPane().add(userLabel);
		
		
		passLabel.setBounds(150, 124, 79, 14);
		getContentPane().add(passLabel);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(263, 121, 105, 20);
		getContentPane().add(passwordField);
		
		regBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			 register();
			
			 if(sucess){
				
				 
				 regSucess.setText("Registered sucessfully");
	

				 
				 logBtn.setEnabled(true);
				 regBtn.setEnabled(false);
			 }
			else{
				 regSucess.setText("Registered failed");
			 }
		}
		});
		regBtn.setBounds(149, 181, 89, 23);
		getContentPane().add(regBtn);
		
		regSucess = new JLabel("");
		regSucess.setBounds(263, 190, 174, 14);
		getContentPane().add(regSucess);
		
		
		logBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LogScreen lgScreen=new LogScreen(p1);
				Login.this.setVisible(false);
				Login.this.dispose();
				
				lgScreen.setVisible(true);
			}
		});
		logBtn.setBounds(149, 240, 89, 23);
		getContentPane().add(logBtn);
		logBtn.setEnabled(false);
		
		
		
	
}
	
	
}
