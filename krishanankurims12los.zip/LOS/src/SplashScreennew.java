
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;

import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JProgressBar;
import javax.swing.JTextField;
import javax.swing.JWindow;
import javax.swing.Timer;

import javazoom.jl.player.Player;

import org.apache.log4j.Logger;


public class SplashScreennew extends JWindow {
	

	
	
	
	
	Logger logger=Logger.getLogger(SplashScreennew.class);
	int color=1;
	int x=33;
	Icon icon=new ImageIcon(SplashScreennew.class.getResource("loan-financing-1024x682.jpg"));
	private final JProgressBar progressBar = new JProgressBar();
	int progressVal=1;
	Timer progressTimer=null;
	private JTextField txtLoading;
	boolean isVisible=true;
	JLabel Loading = new JLabel("Loading..");
	Timer timer=null;
	
	
	 Player playMP3;
	
	public static void main(String[] args) {
		SplashScreennew frame=new SplashScreennew();
		frame.setLocation(420, 235	);
		frame.setVisible(true);
		frame.doAnimation();
		frame.doProgress();
		frame.playSound();

	}

private void playSound(){
	//soundTimer.start();
	try{
	    FileInputStream fis = new FileInputStream("song.mp3");
	    playMP3 = new Player(fis);
	    playMP3.play();
	    logger.debug("file played sucessfully");
	   
	}
	catch(Exception exc){
	  // exc.printStackTrace();
	 logger.debug("Failed to play the file.");
}
}
	



private void doProgress(){
	logger.debug("Progress bar executed");
	
	
	ActionListener l=new ActionListener() {
		
		
		@Override
		public void actionPerformed(ActionEvent e) {
			if(progressVal<=progressBar.getMaximum()){
				
				progressBar.setValue(progressVal);
				progressVal++;
				
			}
			else{
				//soundTimer.stop();
				SplashScreennew.this.setVisible(false);
				if(progressTimer!=null){
					progressTimer.stop();
					playMP3.close();
					logger.debug("Progress bar completed");
				}
				
				SplashScreennew.this.dispose();
				System.out.println("cvbnm,");
				 Login login = new Login();
					System.out.println("1111111111");
					login.setVisible(true);
			
				
				//login.setExtendedState(JFrame.MAXIMIZED_BOTH);
			}
		}
	};
	
	progressTimer =new Timer(50,l);
	progressTimer.start();
	
}
private void doAnimation(){


		Loading.setVisible(isVisible);
		isVisible = !isVisible;
		
	
}
		
	

	
	
	public SplashScreennew() {
		getContentPane().setBackground(Color.WHITE);
		
		setBounds(100, 100, 450, 428);
		
		getContentPane().setLayout(null);
		
		JLabel LoanImage = new JLabel( " ");
		LoanImage.setIcon(icon);
		LoanImage.setBorder(BorderFactory.createLineBorder(Color.BLACK, 4));
		LoanImage.setBounds(-156, 29, 596, 326);
		getContentPane().add(LoanImage);
		progressBar.setBounds(0, 392, 440, 13);
		progressBar.setForeground(Color.CYAN);
		progressBar.setBackground(Color.LIGHT_GRAY);
		getContentPane().add(progressBar);
		
		JLabel LoanText = new JLabel("Customer Acquistion System [CAS]...");
		LoanText.setFont(new Font("Comic Sans MS", Font.BOLD, 16));
		LoanText.setBounds(23, 366, 290, 27);
		getContentPane().add(LoanText);
		
		txtLoading = new JTextField();
		txtLoading.setText("Loading..");
		txtLoading.setBounds(10, 404, -5, 20);
		getContentPane().add(txtLoading);
		txtLoading.setColumns(10);
		
		JLabel Loading = new JLabel("Loading..");
		Loading.setFont(new Font("Vani", Font.BOLD, 13));
		Loading.setBounds(x, 410, 78, 14);
		getContentPane().add(Loading);
		
		
		
		
		
	}
}
