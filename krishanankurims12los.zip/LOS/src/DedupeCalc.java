import org.apache.log4j.Logger;


public class DedupeCalc {
Logger logger=Logger.getLogger(DedupeCalc.class);
	final int MIN_Age=18;
	final int MID_AGE=40;
	final int ADULT_AGE=55;
	
	final int LESS_EXP=5;
	final int MID_EXP=10;
	static double score=0;
	double nationScore=0;
	double ageScore=0;
	double liabScore=0;
	double tenureScore=0;
	double statusScore=0;
	double genderScore=0;
	double professionScore=0;
	boolean correct;
	static boolean loanCheck;
	

	
	public double professionCheck(Person p1){
		logger.debug("in prof blck");
		String exp1=p1.getExperience();
		int exp=Integer.parseInt(exp1);
		if(p1.getProfession()=="Job"){
			if(exp<LESS_EXP){
				professionScore=professionScore+0.5;
				logger.debug(" exp score is "+professionScore);
				return professionScore;
			}
			else if(exp<MID_EXP){
				professionScore=professionScore+1.0;
				logger.debug(" exp score is "+professionScore);
				return professionScore;
			}
			else{
				professionScore=professionScore+1.7;
				logger.debug(" exp escore is "+professionScore);
				return professionScore;
			}
		}
		else{
			if(exp<LESS_EXP){
				professionScore=professionScore+0.3;
				logger.debug("exp score is "+professionScore);
				return professionScore;
			}
			else if(exp<MID_EXP){
				professionScore=professionScore+0.7;
				logger.debug("exp score is "+professionScore);
				return professionScore;
			}
			else{
				professionScore=professionScore+1.3;
				logger.debug("exp score is "+professionScore);
				return professionScore;
			}
		}
		
		
		
	}
	
	public double nationCheck(Person p1){
		if(p1.getNationality()!="Indian"){
			nationScore=nationScore-1.0;
			logger.debug("nation score is "+nationScore);
			return nationScore;
		}
		logger.debug("nation score  is "+nationScore);
		return nationScore;
		
	}
	
	public double genderCheck(Person p1){
		if(p1.getGender()=="Female"){
			logger.debug("female scre");
			genderScore=genderScore+0.4;
			logger.debug("gender score is "+genderScore);
			return genderScore;
		}
		logger.debug("gender else score ois "+genderScore);
		return genderScore;
	}
	
	public double statusCheck(Person p1){

		if(p1.getCreditStatus()== "Single"){
			statusScore=statusScore+0.5;
			logger.debug( "staus sing score is "+statusScore);
			
			return statusScore;
			
			
		}
		else if(p1.getCreditStatus()== "Firm"){
			statusScore=statusScore+1.0;
			
			logger.debug("status firm score is "+statusScore);
			return statusScore;
		}
		else{
			statusScore=statusScore+1.5;
		
			logger.debug(" corp status score is "+statusScore);
			return statusScore;
		}
	}
	
	public double ageCheck(Person p1){
		String age1=p1.getAge();
		int age=Integer.parseInt(age1);
		if(age<MIN_Age || age>ADULT_AGE){
			ageScore=ageScore-1;
			logger.debug("age score is "+ageScore);
			logger.debug("min age scre");
			return ageScore;
			
			
		}
		else if(age>MIN_Age && age<MID_AGE){
			ageScore=ageScore+2;
			logger.debug("mid age scre");
			logger.debug("age score is "+ageScore);
			return ageScore;
		}
		else{
			ageScore=ageScore+1;
			logger.debug("max age scre");
			logger.debug("age score is "+ageScore);
			return ageScore;
		}
	}
	
	public double tenureCheck(Person p1){
		int tenure=Integer.parseInt(p1.getLoanTenure());
		if(tenure<20){
			tenureScore=tenureScore+2.3;
			logger.debug("tenre score is "+tenureScore);
			logger.debug("min tenure scre");
			return tenureScore;
		}
		else if(tenure<30){
			tenureScore=tenureScore+1.7;
			logger.debug("tenre score is "+tenureScore);
			logger.debug("mid ten scre");
			return tenureScore;
		}
		else if(tenure<55){
			logger.debug("mid+ ten scre");
			logger.debug("tenre score is "+tenureScore);
			tenureScore=tenureScore+1.3;
			return tenureScore;
		}
		else{
			tenureScore=tenureScore+0.8;
			logger.debug("max ten scre");
			logger.debug("tenre score is "+tenureScore);
			return tenureScore;
		}
	}

	public boolean loanTypeCheck(Person p1){
		logger.debug("checking");
		int amt=Integer.parseInt(p1.getLoanAmt());
		int value=Integer.parseInt(p1.getLoanValue());
		if(p1.getLoanType()=="Home Loan"){
		logger.debug("in home loan blck");
		if (amt<=((0.85)*value)){
			logger.debug("in home if");
			loanCheck=true;
			
			
		}
		else{
			logger.debug("in home else");
			loanCheck=false;
			
		}
		return loanCheck;	
}
	else if(p1.getLoanType()=="Car Loan"){
		logger.debug("in car loan blk");
		if (amt<=((0.60)*value)){
			logger.debug("in car if");
			loanCheck=true;
			
		}
		else{
			logger.debug("in car else");
			loanCheck=false;
			}
		return loanCheck;
	}
		logger.debug("failure blk");
		return loanCheck;

	}
	public boolean valCheck(String val1,String val2,Person p1){
		int amt=Integer.parseInt(val1);
		int value=Integer.parseInt(val2);
		if(value<amt){
			logger.debug("in value<amt");
			
			correct=false;
			return correct;
			
		}
		else{
		
	logger.debug("in amt<val");
			correct=true;
			return correct;
		}
		
	}
	
	public double liabScore(Person p1){
		
		int liability=Integer.parseInt(p1.getLiability());
		int asset=Integer.parseInt(p1.getAssets());
		
		double checkVal=0.7*(asset);
		double checkVal1=0.4*(asset);
		if(liability>checkVal){
			
			liabScore=liabScore+0.8;
			logger.debug("liab score is "+liabScore);
			return score;
		}
		else if(liability>checkVal1){
			liabScore=liabScore+1.4;
			logger.debug("liab score is "+liabScore);
			return liabScore;
		}
		else{
			liabScore=liabScore+2.1;
			logger.debug("liab score is "+liabScore);
		return liabScore;
	}
	}

}
