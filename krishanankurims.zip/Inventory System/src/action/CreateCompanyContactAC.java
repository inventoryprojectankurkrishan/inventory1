package action;

import com.opensymphony.xwork2.ActionSupport;

public class CreateCompanyContactAC extends ActionSupport
{
		
	
	
	
}
