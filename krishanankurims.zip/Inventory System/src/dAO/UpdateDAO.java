package dAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dTO.CreateStockDTO;

public class UpdateDAO {
	ResultSet rs = null;
	 Connection con = null;
		
		PreparedStatement pstmt1 =null;
	public ResultSet fetchUserDeatils(String pcode) throws SQLException  {
		
			try {
				con = CommonDAO.getConnection();
			
			con.setAutoCommit(false);
			pstmt1=con.prepareStatement(CommonSQL.FETCH_DATA);
			pstmt1.setString(1, pcode);
			rs=pstmt1.executeQuery();
			
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally
			{
				if(pstmt1!=null)
				{
					pstmt1.close();
				}
				
				if(con!=null)
				{
					con.close();
				}
			}
			return rs;

	}
	
	public  int UpdateUserDetails(CreateStockDTO stockDTO)  {
		int i= 0;
		try {
			con = CommonDAO.getConnection();
		
		con.setAutoCommit(false);
		pstmt1=con.prepareStatement(CommonSQL.UPDATE_STOCK);
		pstmt1.setString(1,stockDTO.getPcode());
		pstmt1.setString(2, stockDTO.getPdescription());
		pstmt1.setInt(3 ,stockDTO.getQuantity() );
		pstmt1.setString(4, stockDTO.getPdescription());
		i=pstmt1.executeUpdate();
		
		
	} catch (ClassNotFoundException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		return i;
		
		
	}
	
	}
