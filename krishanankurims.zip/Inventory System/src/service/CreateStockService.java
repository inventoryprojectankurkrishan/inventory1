package service;

import java.sql.SQLException;

import dAO.CreateStockDAO;
import dTO.CreateStockDTO;

public class CreateStockService {

	public boolean createstockService(CreateStockDTO stockDTO) throws ClassNotFoundException, SQLException {
		
		boolean result = false;
		CreateStockDAO stockDAO = new CreateStockDAO();
		result = stockDAO.CreateStockDAO(stockDTO);
		return result;
	}

}
