package action;

import java.sql.ResultSet;

import com.opensymphony.xwork2.ActionSupport;

import dAO.UpdateDAO;

public class UpdateSTOCKAC extends ActionSupport {
	UpdateDAO updatedao = new UpdateDAO();
	ResultSet rs = null;
	String pcode;
	String pname;
	int quantity ;
	String pdescription;
	String submittype;
	
	public ResultSet getRs() {
		return rs;
	}

	public void setRs(ResultSet rs) {
		this.rs = rs;
	}

	public String getPcode() {
		return pcode;
	}

	public void setPcode(String pcode) {
		this.pcode = pcode;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getPdescription() {
		return pdescription;
	}

	public void setPdescription(String pdescription) {
		this.pdescription = pdescription;
	}

	public String execute() {
		
		if(submittype.equals("updatedata")) {
//			rs=updatedao.fetchUserDeatils(pcode);
//			if(rs!=null) {
//				pcode=rs.getString("pcode");
//				
//			}
		}
		
		
		return SUCCESS;
		
		
	}
}
