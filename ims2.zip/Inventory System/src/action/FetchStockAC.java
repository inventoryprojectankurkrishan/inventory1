package action;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.opensymphony.xwork2.ActionSupport;

//import dAO.FetchContactDataDAO;
import dAO.fetchStockDAO;
//import dTO.FetchContactDTO;
import dTO.FetchStockDTO;

public class FetchStockAC extends ActionSupport {
	String fetchData = null;
	ArrayList<FetchStockDTO> dataList=null;
	ResultSet rs = null;
	FetchStockDTO daoobj =null;
	
	
	
	
      public FetchStockDTO getDaoobj() {
		return daoobj;
	}





	public void setDaoobj(FetchStockDTO daoobj) {
		this.daoobj = daoobj;
	}





	public String getFetchData() {
		return fetchData;
	}





	public void setFetchData(String fetchData) {
		this.fetchData = fetchData;
	}





	public ArrayList<FetchStockDTO> getDataList() {
		return dataList;
	}





	public void setDataList(ArrayList<FetchStockDTO> dataList) {
		this.dataList = dataList;
	}





	public ResultSet getRs() {
		return rs;
	}





	public void setRs(ResultSet rs) {
		this.rs = rs;
	}





	public String execute() {
    	  if(fetchData != null) {
    	 
    	  
     		 if (fetchData.equals("FetchStock"))
     		 {
 				dataList = new ArrayList<FetchStockDTO>();
 				FetchStockDTO dataBean = null;
 				rs = new fetchStockDAO ().fetchStockData();
 				if(rs!=null)
 				{
 					try 
 					{
 						while(rs.next())
 						{
 							dataBean= new FetchStockDTO();
 							dataBean.setPcode(rs.getLong("pcode"));
 							dataBean.setPdescription(rs.getString("pdescription"));
 							dataBean.setPname(rs.getString("pname"));
 							dataBean.setQuantity(rs.getInt("quantity"));
 							dataList.add(dataBean);
 							System.out.println("88888888"+dataList);
 						}
 					
 					} 
 					catch (SQLException e) 
 					{
 						// TODO Auto-generated catch block
 						e.printStackTrace();
 					}
 				}
     		 }
 	     
    	  
    	  }
    	  else
    	  {
    		  System.out.println("fetch data is null");
    	  }
    	  
    	  
    	  
    	  
    	  
		return SUCCESS ;
    	  
      }
}



