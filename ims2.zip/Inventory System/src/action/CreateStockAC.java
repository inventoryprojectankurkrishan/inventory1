package action;

import java.sql.SQLException;

import com.opensymphony.xwork2.ActionSupport;

import dTO.CreateStockDTO;
import service.CreateStockService;

public class CreateStockAC extends ActionSupport{
	String pcode;
	String pname;
	int quantity ;
	String pdescription;
	
	public String getPcode() {
		return pcode;
	}
	public void setPcode(String pcode) {
		this.pcode = pcode;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getPdescription() {
		return pdescription;
	}
	public void setPdescription(String pdescription) {
		this.pdescription = pdescription;
	}
	
	public String execute() {
		String getResult= ERROR;
		
		CreateStockDTO stockDTO = createStock();
		CreateStockService stockService = new CreateStockService();
		try {
			if(stockService.createstockService(stockDTO)) {
				getResult=SUCCESS;
				
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return getResult;
		
	}
	
	public CreateStockDTO createStock() {
		CreateStockDTO stockDTO = new CreateStockDTO();
		stockDTO.setPcode(pcode);
		stockDTO.setPname(pname);
		stockDTO.setQuantity(quantity);
		stockDTO.setPdescription(pdescription);
		
		System.out.println("666666"+stockDTO.toString());
		return stockDTO;
		
	}
	
}
