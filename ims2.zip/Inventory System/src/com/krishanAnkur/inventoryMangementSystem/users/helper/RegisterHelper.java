package com.krishanAnkur.inventoryMangementSystem.users.helper;

import java.sql.SQLException;

import com.krishanAnkur.inventoryMangementSystem.users.dAO.RegisterDAO;
import com.krishanAnkur.inventoryMangementSystem.users.dTO.RegisterDTO;

public class RegisterHelper {

	public boolean doRegister(RegisterDTO RegisterUserDTO) throws ClassNotFoundException, SQLException {
		boolean getresult = false;
		//String getStringResult = "ERROR";
		RegisterDAO registerDAO = new RegisterDAO();
		getresult=registerDAO.doRegister(RegisterUserDTO);
		return getresult;
	}

}
