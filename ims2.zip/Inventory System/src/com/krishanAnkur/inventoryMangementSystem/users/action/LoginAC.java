package com.krishanAnkur.inventoryMangementSystem.users.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.struts2.dispatcher.SessionMap;
import org.apache.struts2.interceptor.SessionAware;

import com.krishanAnkur.inventoryMangementSystem.users.dTO.DashboardDTO;
import com.krishanAnkur.inventoryMangementSystem.users.dTO.LoginDTO;
import com.krishanAnkur.inventoryMangementSystem.users.dTO.LoginResultDTO;
import com.krishanAnkur.inventoryMangementSystem.users.service.LoginService;
import com.opensymphony.xwork2.ActionSupport;

public class LoginAC extends ActionSupport implements SessionAware{
	String userid;
	String password;
	List <DashboardDTO> list = null; 
	SessionMap<String,String> sessionmap;
	
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public List<DashboardDTO> getList() {
		return list;
	}
	public void setList(List<DashboardDTO> list) {
		this.list = list;
	}
	@Override
	public String execute()
	{	
		String result="loginerror";
		LoginResultDTO loginResultDTO=null;
		DashboardDTO dashboardDTO=null;
		
		LoginDTO loginDTO = new LoginDTO();
		loginDTO.setUserid(userid);
		loginDTO.setPassword(password);
	
		LoginService loginService=new LoginService();
		
		loginResultDTO=loginService.doLogin(loginDTO);
		if(loginResultDTO!=null)
		{	System.out.println("loginService.doLogin successful");
			if(loginResultDTO.getResult())
			{	
				list = new ArrayList<DashboardDTO>();
				dashboardDTO=loginResultDTO.getDashboardDTO();
				System.out.println(dashboardDTO);
				result=SUCCESS;
				list.add(dashboardDTO);
			}
		}
		
		return result;
	}
	public void setSession(Map map) {  
	    sessionmap=(SessionMap)map;  
	    sessionmap.put("login","true");  
	}  
	public String logout(){  
	    sessionmap.invalidate();  
	    return "success";  
	}  
}
