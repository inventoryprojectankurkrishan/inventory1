package com.krishanAnkur.inventoryMangementSystem.users.service;

import com.krishanAnkur.inventoryMangementSystem.users.dTO.DashboardDTO;
import com.krishanAnkur.inventoryMangementSystem.users.dTO.LoginDTO;
import com.krishanAnkur.inventoryMangementSystem.users.dTO.LoginResultDTO;
import com.krishanAnkur.inventoryMangementSystem.users.helper.LoginHelper;

public class LoginService {
		public LoginResultDTO doLogin(LoginDTO loginDTO)
		{
			boolean result=false;
			LoginResultDTO loginResultDTO=null;
			DashboardDTO dashboardDTO=null;
			LoginHelper loginHelper = new LoginHelper();
			if(loginHelper.checkUseridPassword(loginDTO))
						{	
							dashboardDTO=loginHelper.doLogin(loginDTO.getUserid());
							if(dashboardDTO!=null)
								{
									if(loginHelper.setLastLogin(loginDTO.getUserid()))
										{	
											result=true;
											loginResultDTO =new LoginResultDTO();
											loginResultDTO.setDashboardDTO(dashboardDTO);
											loginResultDTO.setResult(result);
										}
								}	
						}						
			return loginResultDTO;
		}
}
