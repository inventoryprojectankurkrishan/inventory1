package com.krishanAnkur.inventoryMangementSystem.users.service;

import java.sql.SQLException;

import com.krishanAnkur.inventoryMangementSystem.users.dTO.RegisterDTO;
import com.krishanAnkur.inventoryMangementSystem.users.helper.RegisterHelper;

public class RegisterService {
	public boolean registerUserService(RegisterDTO RegisterUserDTO) throws ClassNotFoundException, SQLException
	{
		boolean getResult=false;
		RegisterHelper registerHelper =new RegisterHelper();
		getResult=registerHelper.doRegister(RegisterUserDTO);
		
		return getResult;
	}
}
