package com.krishanAnkur.inventoryMangementSystem.contact.helper;

import java.sql.SQLException;

import com.krishanAnkur.inventoryMangementSystem.contact.dAO.CreateIndividualContactDAO;
import com.krishanAnkur.inventoryMangementSystem.contact.dTO.CreateIndividualContactDTO;

public class CreateIndividualConatctHelper {

	public boolean createIndContactHelper(CreateIndividualContactDTO indContactDTO) {
		boolean result = false;
		CreateIndividualContactDAO individualDAO = new CreateIndividualContactDAO();
		
		try 
		{
			result =  individualDAO.createIndContactDAO(indContactDTO);
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		catch (ClassNotFoundException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result ;
	}
}
