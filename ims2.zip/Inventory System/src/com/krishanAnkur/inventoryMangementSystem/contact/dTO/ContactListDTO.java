package com.krishanAnkur.inventoryMangementSystem.contact.dTO;

public class ContactListDTO {
	

}
